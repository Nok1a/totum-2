<?php
/**
 * Created by PhpStorm.
 * User: tatiana
 * Date: 22.03.17
 * Time: 14:20
 */

namespace totum\models;

use totum\common\Model;

class TreeV extends Model
{
    protected bool $isServiceTable=true;
}
