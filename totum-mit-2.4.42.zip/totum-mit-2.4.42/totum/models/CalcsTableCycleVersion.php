<?php
/**
 * Created by PhpStorm.
 * User: tatiana
 * Date: 2019-02-28
 * Time: 13:43
 */

namespace totum\models;

use totum\common\Model;

class CalcsTableCycleVersion extends Model
{
}
