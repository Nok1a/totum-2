<?php
/**
 * Created by PhpStorm.
 * User: tatiana
 * Date: 20.03.17
 * Time: 16:19
 */

namespace totum\models;

use totum\common\Model;

class NonProjectCalcs extends Model
{
    protected $idFieldName = 'tbl_name';
}
