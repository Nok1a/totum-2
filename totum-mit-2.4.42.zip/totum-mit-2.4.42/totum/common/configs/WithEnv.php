<?php


namespace totum\common\configs;

trait WithEnv
{
    protected function getEnvSettings()
    {

        /*dsdfsfsdf*/
    }
}
