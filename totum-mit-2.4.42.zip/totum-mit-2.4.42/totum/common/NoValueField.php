<?php


namespace totum\common;

/*
 * do nothing
 * */
class NoValueField extends Field
{
}
