<?php


namespace totum\common;

class criticalErrorException extends \Exception
{
    use WithPathMessTrait;
}
