<?php
/**
 * Created by PhpStorm.
 * User: tatiana
 * Date: 2019-01-23
 * Time: 10:16
 */

namespace totum\common;

class tableSaveOrDeadLockException extends \Exception
{
}
