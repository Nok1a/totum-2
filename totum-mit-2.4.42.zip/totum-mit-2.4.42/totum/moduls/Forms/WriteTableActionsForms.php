<?php


namespace totum\config\totum\moduls\Forms;

use totum\moduls\Table\WriteTableActions;

class WriteTableActionsForms extends WriteTableActions
{
    use FormsTrait;
}
