<?php


namespace totum\config\totum\moduls\Forms;

use Psr\Http\Message\ServerRequestInterface;
use totum\common\Totum;
use totum\moduls\Table\ReadTableActions;
use totum\tableTypes\aTable;

class ReadTableActionsForms extends ReadTableActions
{
    use FormsTrait;


}
