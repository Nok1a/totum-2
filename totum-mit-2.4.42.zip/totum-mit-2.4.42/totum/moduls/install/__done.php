<?php

use totum\common\Lang\RU;

?>
<div class="page_content" style=" margin: 15%;">
    <div class="panel" style="
    margin-top: 100px;
    padding: 20px;
    background-color: #fafafa;
    font-size: 16px;
    display: block;
">
        <?=$this->translate('Conf.php was created successfully. Connection to the database is set up, the start scheme is installed. You are authorized under specified login with the role of Creator. Click the link or refresh the page.')?>

        <div style="
    margin-top: 15px;
"><a href="/"><?=$this->translate('Have a successful use of the system')?></a></div>
    </div>
</div>