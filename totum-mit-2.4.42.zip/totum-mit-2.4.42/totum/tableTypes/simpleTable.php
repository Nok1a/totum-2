<?php
/**
 * Created by PhpStorm.
 * User: tatiana
 * Date: 13.03.17
 * Time: 16:41
 */

namespace totum\tableTypes;

use totum\common\sql\Sql;
use totum\common\Totum;

class simpleTable extends RealTables
{
}
